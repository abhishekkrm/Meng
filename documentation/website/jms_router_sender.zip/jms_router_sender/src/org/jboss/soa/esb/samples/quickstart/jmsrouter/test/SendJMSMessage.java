/*
 * JBoss, Home of Professional Open Source
 * Copyright 2006, JBoss Inc., and others contributors as indicated
 * by the @authors tag. All rights reserved.
 * See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU Lesser General Public License, v. 2.1.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License,
 * v.2.1 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2005-2006,
 * @author JBoss Inc.
 */
package org.jboss.soa.esb.samples.quickstart.jmsrouter.test;

import java.util.Properties;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;
import javax.jms.Destination;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.MessageConsumer;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;


/**
 *
 * @author <a href="mailto:daniel.bevenius@gmail.com">Daniel Bevenius</a>
 *
 */
public class SendJMSMessage
{
    private Connection connection;
    private Session session;
    private Destination gatewayDestination;
    private Destination responseDestination;
    private Destination replyToDestination;
    private String correlationId;

	private String propertyKey = "MyProperty";

    public void setupConnection(String destination) throws JMSException, NamingException
    {
		InitialContext iniCtx = new InitialContext();

    	ConnectionFactory connectionFactory = (ConnectionFactory) iniCtx.lookup("ConnectionFactory");

    	connection = connectionFactory.createConnection();

    	gatewayDestination = (Destination) iniCtx.lookup("queue/quickstart_jms_router_Request_gw");
    	responseDestination = (Destination)iniCtx.lookup(destination);
    	replyToDestination = (Destination) iniCtx.lookup("queue/quickstart_jms_router_replyToQueue");
    	session = connection.createSession(false, QueueSession.AUTO_ACKNOWLEDGE);
    	connection.start();
    	System.out.println("Connection Started");
    }

    public void stop() throws JMSException
    {
        session.close();
        connection.stop();
        connection.close();
    }

    public synchronized void sendAMessage(String msg) throws JMSException {
    	//correlationId = "QuickstartId[" + java.util.Calendar.getInstance().get( java.util.Calendar.SECOND ) + "]";
		correlationId = "QuickstartId[Abhishek]";
        MessageProducer producer = session.createProducer(gatewayDestination);
        ObjectMessage objectMsg = session.createObjectMessage(msg);
        objectMsg.setJMSCorrelationID( correlationId );
		objectMsg.setJMSReplyTo( replyToDestination );
		objectMsg.setStringProperty(propertyKey, "My property value");

        producer.send(objectMsg);
    	System.out.println("Sent message with CorrelationID : " + correlationId );
    	System.out.println("");
        producer.close();
    }


    public static void main(String args[]) throws Exception
    {
		Server s = new Server();
    	SendJMSMessage sm = new SendJMSMessage();
    	sm.setupConnection(args[1]);		
		s.startServer(sm);
    	//sm.sendAMessage(args[0]);
    	//sm.receiveAMessage();
    	sm.stop();
    }

}

class Server {
	
	private static final int PORT = 10000;
	private static ServerSocket serverSocket = null;
	private SendJMSMessage sm = null;
	/**
	 * @param args
	 */
	public void startServer(SendJMSMessage sm) {
		this.sm = sm;
		try{
			serverSocket = new ServerSocket(PORT);
			while(true){
				Socket socket = serverSocket.accept();
				System.out.println("Received Connection \n");
				new EsbSenderThread(socket, sm).start();
			}
		} catch(IOException ioe){
			ioe.printStackTrace();
		}	
		
	}
	
	public void finalize(){
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

class EsbSenderThread extends Thread {
	private Socket socket = null;
	private byte[] bbuf = new byte[4096];
	private String msg = null;
	private SendJMSMessage sm = null;
	
	public EsbSenderThread(Socket socket, SendJMSMessage sm){
		this.socket = socket;
		this.sm = sm;
	}
	
	public void run() {
		try {
			InputStream is = socket.getInputStream();
			int i = 0;
			byte b;
			while( (b=(byte)is.read()) != -1)
				bbuf[i++] = b;
			msg = new String(bbuf,0,i);
			System.out.println("Message to send to ESB server is: " + msg);
			sm.sendAMessage(msg);
			is.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		}
	}
}

