﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SomeStuff
{
    [QS.Fx.Reflection.ComponentClass("5`1", "EmbeddedObjects")]
    public partial class EmbeddedObjects : 
        UserControl, 
        QS.Fx.Object.Classes.IUI,
        QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            EmbeddedObjectsUpdate, 
            EmbeddedObjectsCheckpoint>
    {
        public EmbeddedObjects
        (
            [QS.Fx.Reflection.Parameter("channel", QS.Fx.Reflection.ParameterClass.Value)]
                QS.Fx.Object.IReference<
                    QS.Fx.Object.Classes.ICheckpointedCommunicationChannel<
                        EmbeddedObjectsUpdate, 
                        EmbeddedObjectsCheckpoint>> channel,

            [QS.Fx.Reflection.Parameter("loader", QS.Fx.Reflection.ParameterClass.Value)] 
                QS.Fx.Object.IReference<
                    QS.Fx.Object.Classes.IService<
                        QS.Fx.Interface.Classes.ILoader<
                            QS.Fx.Object.Classes.IObject>>> loader
        )
        {
            InitializeComponent();

            this.uiendpoint = QS.Fx.Endpoint.Internal.Create.ExportedUI(this);
            
            this.loaderendpoint = 
                QS.Fx.Endpoint.Internal.Create.ImportedInterface<
                    QS.Fx.Interface.Classes.ILoader<
                        QS.Fx.Object.Classes.IObject>>();
            
            this.channelendpoint = 
                QS.Fx.Endpoint.Internal.Create.DualInterface<
                    QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<
                        EmbeddedObjectsUpdate, 
                        EmbeddedObjectsCheckpoint>,
                    QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
                        EmbeddedObjectsUpdate, 
                        EmbeddedObjectsCheckpoint>>(this);

            this.loaderconnection = this.loaderendpoint.Connect(loader.Object.Endpoint);            
            this.channelconnection = this.channelendpoint.Connect(channel.Object.Channel);
        }

        private QS.Fx.Endpoint.Classes.IExportedUI uiendpoint;

        private QS.Fx.Endpoint.Internal.IImportedInterface<
            QS.Fx.Interface.Classes.ILoader<
                QS.Fx.Object.Classes.IObject>> loaderendpoint;
        
        private QS.Fx.Endpoint.Internal.IDualInterface<
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<
                EmbeddedObjectsUpdate, 
                EmbeddedObjectsCheckpoint>,
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
                EmbeddedObjectsUpdate, 
                EmbeddedObjectsCheckpoint>> channelendpoint;
        
        private QS.Fx.Endpoint.IConnection loaderconnection, channelconnection;
        
        private List<string> xmldefinitions = new List<string>();
        private Queue<string> pendingxmldefinitions = new Queue<string>();

        private List<QS.Fx.Endpoint.IConnection> connections = new List<QS.Fx.Endpoint.IConnection>();

        private static readonly QS.Fx.Reflection.IObjectClass uiobjectclass = 
            QS.Fx.Reflection.Library.Create.ObjectClass<QS.Fx.Object.Classes.IUI>();

        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return this.uiendpoint; }
        }

        EmbeddedObjectsCheckpoint 
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
                EmbeddedObjectsUpdate, 
                EmbeddedObjectsCheckpoint>.Checkpoint()
        {
            lock (this)
            {
                return (this.xmldefinitions != null) ? 
                    new EmbeddedObjectsCheckpoint(this.xmldefinitions.ToArray()) : 
                    null;
            }
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            EmbeddedObjectsUpdate, 
            EmbeddedObjectsCheckpoint>.Initialize(
                EmbeddedObjectsCheckpoint checkpoint)
        {
            lock (this)
            {
                this.xmldefinitions.Clear();
                this.pendingxmldefinitions.Clear();
                
                if (checkpoint != null)
                {
                    string[] xmldefinitions = checkpoint.xmldefinitions;
                    if (xmldefinitions != null)
                    {
                        this.xmldefinitions.AddRange(xmldefinitions);
                        foreach (string xmldefinition in xmldefinitions)
                            pendingxmldefinitions.Enqueue(xmldefinition);
                    }
                }

                this.LoadEmbeddedObject();
            }
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            EmbeddedObjectsUpdate, 
            EmbeddedObjectsCheckpoint>.Receive(
                EmbeddedObjectsUpdate message)
        {
            lock (this)
            {
                switch (message.updatetype)
                {
                    case EmbeddedObjectsUpdate.UpdateType.AddObject:
                        {
                            string xmldefinition = message.xmldefinition;

                            this.xmldefinitions.Add(xmldefinition);
                            this.pendingxmldefinitions.Enqueue(xmldefinition);
                        }
                        break;

                    default:
                        throw new NotImplementedException();
                }

                this.LoadEmbeddedObject();
            }
        }

        private void LoadEmbeddedObject()
        {
            if (this.InvokeRequired)
                this.BeginInvoke(new QS.Fx.Base.Callback(this.LoadEmbeddedObject));
            else
            {
                lock (this)
                {
                    while (this.pendingxmldefinitions.Count > 0)
                        this.LoadEmbeddedObject(this.pendingxmldefinitions.Dequeue());
                }
            }
        }

        private void LoadEmbeddedObject(string xmldefinition)
        {
            QS.Fx.Object.IReference<QS.Fx.Object.Classes.IObject> reference = 
                this.loaderendpoint.Interface.Load(xmldefinition);            
            
            if (reference.ObjectClass.IsSubtypeOf(uiobjectclass))
            {
                QS.Fx.Object.IReference<QS.Fx.Object.Classes.IUI> uireference =
                    reference.CastTo<QS.Fx.Object.Classes.IUI>();

                QS.Fx.Object.Classes.IUI uiobject = uireference.Object;

                QS.Fx.Endpoint.Classes.IImportedUI internaluiendpoint =
                    QS.Fx.Endpoint.Internal.Create.ImportedUI(this.flowLayoutPanel1);

                this.connections.Add(internaluiendpoint.Connect(uiobject.UI));
            }
        }

        private void EmbeddedObjects_DragEnter(object sender, DragEventArgs e)
        {
            lock (this)
            {
                if (this.loaderendpoint.IsConnected && 
                    this.channelendpoint.IsConnected && 
                    e.Data.GetDataPresent(DataFormats.UnicodeText, true))
                {
                    e.Effect = DragDropEffects.All;
                }
                else
                    e.Effect = DragDropEffects.None;
            }
        }

        private void EmbeddedObjects_DragDrop(object sender, DragEventArgs e)
        {
            lock (this)
            {
                if (e.Data.GetDataPresent(DataFormats.UnicodeText, true))
                {
                    string xmldefinition = (string) e.Data.GetData(DataFormats.UnicodeText);

                    this.channelendpoint.Interface.Send(
                        new EmbeddedObjectsUpdate(
                            EmbeddedObjectsUpdate.UpdateType.AddObject, 
                            xmldefinition));                    
                }
            }
        }
    }
}
