﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SomeStuff
{
    [QS.Fx.Reflection.ValueClass("4`1", "EmbeddedObjectsUpdate")]
    public sealed class EmbeddedObjectsUpdate
    {
        public enum UpdateType
        {
            AddObject
        }

        public EmbeddedObjectsUpdate(UpdateType updatetype, string xmldefinition)
        {
            this.updatetype = updatetype;
            this.xmldefinition = xmldefinition;
        }

        public EmbeddedObjectsUpdate()
        {
        }

        [XmlAttribute]
        public UpdateType updatetype;
        [XmlAttribute]
        public string xmldefinition;
    }
}
