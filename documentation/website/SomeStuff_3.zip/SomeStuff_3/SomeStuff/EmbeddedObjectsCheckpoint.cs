﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SomeStuff
{
    [QS.Fx.Reflection.ValueClass("5`1", "EmbeddedObjectsCheckpoint")]
    public sealed class EmbeddedObjectsCheckpoint
    {
        public EmbeddedObjectsCheckpoint(string[] xmldefinitions)
        {
            this.xmldefinitions = xmldefinitions;
        }

        public EmbeddedObjectsCheckpoint()
        {
        }

        [XmlElement]
        public string[] xmldefinitions;
    }
}
