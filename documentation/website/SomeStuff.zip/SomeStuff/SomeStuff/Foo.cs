﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SomeStuff
{
    [QS.Fx.Reflection.ComponentClass("1`1", "Foo", "This is my custom object Foo.")]
    public sealed partial class Foo : UserControl, QS.Fx.Object.Classes.IUI,
        QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<QS.Fx.Value.Classes.IText, QS.Fx.Value.Classes.IText>
    {
        public Foo(
            [QS.Fx.Reflection.Parameter("channel", QS.Fx.Reflection.ParameterClass.Value)] 
            QS.Fx.Object.IReference<
                QS.Fx.Object.Classes.ICheckpointedCommunicationChannel<
                    QS.Fx.Value.Classes.IText, 
                    QS.Fx.Value.Classes.IText>> channel)
        {
            InitializeComponent();
            this.myendpoint = QS.Fx.Endpoint.Internal.Create.ExportedUI(this);
            this.channelproxy = channel.Object;
            this.mychannelendpoint = QS.Fx.Endpoint.Internal.Create.DualInterface<
                QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<
                    QS.Fx.Value.Classes.IText,
                    QS.Fx.Value.Classes.IText>,
                QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
                    QS.Fx.Value.Classes.IText,
                    QS.Fx.Value.Classes.IText>>(this);
            this.connectiontochannel = this.mychannelendpoint.Connect(this.channelproxy.Channel);
        }

        private QS.Fx.Endpoint.Internal.IExportedUI myendpoint;
        private QS.Fx.Object.Classes.ICheckpointedCommunicationChannel<
                        QS.Fx.Value.Classes.IText, 
                        QS.Fx.Value.Classes.IText> channelproxy;
        private QS.Fx.Endpoint.Internal.IDualInterface<
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<
                QS.Fx.Value.Classes.IText,
                QS.Fx.Value.Classes.IText>,
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
                QS.Fx.Value.Classes.IText,
                QS.Fx.Value.Classes.IText>> mychannelendpoint;
        private QS.Fx.Endpoint.IConnection connectiontochannel;

        private Queue<MyEvent> myevents = new Queue<MyEvent>();

        private struct MyEvent
        {
            public MyEvent(Category category, QS.Fx.Value.Classes.IText text)
            {
                this.category = category;
                this.text = text;
            }

            public Category category;
            public QS.Fx.Value.Classes.IText text;

            public enum Category
            {
                Initialization, Update
            }
        }

        #region IUI Members

        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return this.myendpoint; }
        }

        #endregion

        #region ICheckpointedCommunicationChannelClient<IText,IText> Members

        QS.Fx.Value.Classes.IText QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            QS.Fx.Value.Classes.IText, 
            QS.Fx.Value.Classes.IText>.Checkpoint()
        {
            return new QS.Fx.Value.UnicodeText(this.textBox1.Text);
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            QS.Fx.Value.Classes.IText, 
            QS.Fx.Value.Classes.IText>.Initialize(QS.Fx.Value.Classes.IText _checkpoint)
        {
            lock (myevents)
            {
                bool pendingcallback = myevents.Count > 0;
                myevents.Enqueue(new MyEvent(MyEvent.Category.Initialization, _checkpoint));
                if (!pendingcallback)
                    this.ScheduleCallback();
            }
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<
            QS.Fx.Value.Classes.IText, 
            QS.Fx.Value.Classes.IText>.Receive(QS.Fx.Value.Classes.IText _message)
        {
            lock (myevents)
            {
                bool pendingcallback = myevents.Count > 0;
                myevents.Enqueue(new MyEvent(MyEvent.Category.Update,_message));
                if (!pendingcallback)
                    this.ScheduleCallback();
            }
        }

        private void ScheduleCallback()
        {
            if (this.InvokeRequired)
                this.BeginInvoke(new EventHandler(this.MyCallback), null);
            else
                this.MyCallback(null, null);
        }

        private void MyCallback(object sender, EventArgs args)
        {
            lock (myevents)
            {
                while (myevents.Count > 0)
                {
                    MyEvent e = myevents.Dequeue();
                    switch (e.category)
                    {
                        case MyEvent.Category.Initialization:
                            textBox1.Text = (e.text != null) ? e.text.Text : string.Empty;
                            break;

                        case MyEvent.Category.Update:
                            textBox1.Text = textBox1.Text + ((e.text != null) ? e.text.Text : string.Empty);
                            break;

                        default:
                            throw new NotImplementedException();
                    }
                }
            }
        }

        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            string some_text = "message from process " + System.Diagnostics.Process.GetCurrentProcess().Id.ToString() +
                " generated at " + System.DateTime.Now.ToString() + "\r\n";
            this.mychannelendpoint.Interface.Send(new QS.Fx.Value.UnicodeText(some_text));
        }
    }
}
