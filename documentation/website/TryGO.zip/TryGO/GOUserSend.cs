﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using GOTransport.Frontend;
using System.Diagnostics;
using GOTransport.GOBaseLibrary;
using System.IO;

namespace GOTransport.Examples
{
    [QS.Fx.Reflection.ComponentClass("4`1", "GOUserSend")]
    public sealed partial class GOUserSend :
        UserControl,
        QS.Fx.Object.Classes.IUI,
        IGOResponse
    {
        delegate Rumor ReceiveCallback();
        static long staticCounter = 0;
        
        private void initService(Dictionary<string, string> _loConfig)
        {
            String[] nodeInformation;
            String[] groupMembership;
            String[] connections;

            if (goTransportEndpoint.Interface.HasGraphData() == true)
            {
                return;
            }

            nodeIdNodeMap = new Dictionary<string, IGraphElement>();
            groupIdGroupMap = new Dictionary<string, IGraphElement>();
            groupMembership = _loConfig["GROUP_MEMBERSHIP"].Split('|'); ;
            nodeInformation = _loConfig["NODE_INFORMATION"].Split('|'); ;
            connections = _loConfig["CONNECTIONS"].Split('|'); ;

            String nodesToInitialize = _loConfig["NODES_TO_INITIALIZE"];

            foreach (String nodeInfo in nodeInformation)
            {
                String[] splitNodeInfo = nodeInfo.Split(':');
                Node node = new Node(splitNodeInfo[1]);
                node.SetAddress(splitNodeInfo[0] + ":" + splitNodeInfo[1]);
                nodeIdNodeMap[splitNodeInfo[1]] = node;
            }

            if (nodesToInitialize != null)
            {
                String[] portInitializationList = nodesToInitialize.Split(',');

                foreach (String port in portInitializationList)
                {
                    goTransportEndpoint.Interface.SetWorkingContext(port);

                    foreach (String groupInfo in groupMembership)
                    {
                        String[] splitGroupInfo = groupInfo.Split(':', ',');
                        Group group = new Group(splitGroupInfo[0], Int32.Parse(splitGroupInfo[1]));
                        groupIdGroupMap[splitGroupInfo[0]] = group;

                        for (int nodeIter = 2; nodeIter < splitGroupInfo.Length; nodeIter++)
                        {
                            goTransportEndpoint.Interface.AddNode(group, nodeIdNodeMap[splitGroupInfo[nodeIter]] as Node);
                        }
                    }

                    foreach (String connection in connections)
                    {
                        String[] nodePair = connection.Split(':');
                        goTransportEndpoint.Interface.Connect(nodeIdNodeMap[nodePair[0]] as Node, nodeIdNodeMap[nodePair[1]] as Node, 1);
                    }

                    goTransportEndpoint.Interface.InitializationComplete();
                }
            }

            goTransportEndpoint.Interface.SetHasGraphData(true);
        }

        public GOUserSend(
            QS.Fx.Object.IContext _mycontext,
             [QS.Fx.Reflection.Parameter("GROUP_MEMBERSHIP", QS.Fx.Reflection.ParameterClass.Value)]
            string _groupMembership,
             [QS.Fx.Reflection.Parameter("NODE_INFORMATION", QS.Fx.Reflection.ParameterClass.Value)]
            string _nodeInformation,
             [QS.Fx.Reflection.Parameter("CONNECTIONS", QS.Fx.Reflection.ParameterClass.Value)]
            string _connections,
             [QS.Fx.Reflection.Parameter("NODES_TO_INITIALIZE", QS.Fx.Reflection.ParameterClass.Value)]
            string _nodesToInitialize,
            [QS.Fx.Reflection.Parameter("GOTransport", QS.Fx.Reflection.ParameterClass.Value)] 
                QS.Fx.Object.IReference<IGOTransport> GOTransport)
        {
            Dictionary<string, string> loConfig = new Dictionary<string, string>();
            loConfig["GROUP_MEMBERSHIP"] = _groupMembership;
            loConfig["NODE_INFORMATION"] = _nodeInformation;
            loConfig["CONNECTIONS"] = _connections;
            loConfig["NODES_TO_INITIALIZE"] = _nodesToInitialize;

            InitializeComponent();

            Debug.WriteLineIf(Utils.debugSwitch.Verbose,"Control ctor<" + counter + ">");
            if (counter == 0)
            {
                ControlDesignerCounter = 1;
                if (uiendpoint == null && goTransportEndpoint == null && goTransportConnection == null)
                {
                    uiendpoint = _mycontext.ExportedUI(this);
                    goTransportEndpoint = _mycontext.DualInterface<IGORequest, IGOResponse>(this);
                    goTransportConnection = goTransportEndpoint.Connect(GOTransport.Dereference(_mycontext).goTransport);
                }
            }

            initService(loConfig);

            counter++;
        }

        static private QS.Fx.Endpoint.Internal.IExportedUI uiendpoint = null;
        static private QS.Fx.Endpoint.Internal.IDualInterface<IGORequest, IGOResponse> goTransportEndpoint = null;
        static private QS.Fx.Endpoint.IConnection goTransportConnection = null;
        static int counter = 0;

        static Dictionary<String, IGraphElement> nodeIdNodeMap;
        static Dictionary<String, IGraphElement> groupIdGroupMap;

        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return uiendpoint; }
        }

        void IGOResponse.Ready()
        {
        }

        void IGOResponse.Alert(Rumor rumor)
        {
        }

        #region IGOResponse Members


        void IGOResponse.Notify(QS.Fx.Object.IReference<QS.Fx.Object.Classes.IObject> notifyMessage)
        {
            throw new NotImplementedException();
        }

        #endregion

        private void Gossip_Click(object _sender, EventArgs _ev)
        {
            const int MAX_RUMORS_TO_SEND = 10;

            goTransportEndpoint.Interface.SetWorkingContext("30001");
            staticCounter = DateTime.Now.Ticks;
            long length = staticCounter + MAX_RUMORS_TO_SEND;

            progressBar1.Minimum = 0;
            progressBar1.Maximum = MAX_RUMORS_TO_SEND;

            for (; staticCounter < length; staticCounter++)
            {
                Rumor rumorToFeed = new Rumor("" + staticCounter, "some payload");
                rumorToFeed.DestinationNode = new Node("30002") as Node;
                rumorToFeed.DestinationGroup = new Group("group_3", 100) as Group;
                rumorToFeed.HopCount = 2;

                rumorToFeed.SourceGroup = new Group("group_1", 100) as Group;
                rumorToFeed.SourceNode = new Node("30001") as Node;
                goTransportEndpoint.Interface.Send(rumorToFeed);
                progressBar1.Value++;
            }

            Gossip.Text = "Done";
            label2.Text = "All Gossips sent";
            Gossip.Enabled = false;
        }
    }
}
