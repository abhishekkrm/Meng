﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Diagnostics;
using System.Threading;
using GOTransport.GOBaseLibrary;
using System.Runtime.Remoting.Messaging;
using GOTransport.Frontend;

namespace GOTransport.Examples
{
    [QS.Fx.Reflection.ComponentClass("3`1", "GOUserReceive")]
    public sealed partial class GOUserReceive :
        UserControl,
        QS.Fx.Object.Classes.IUI,
        IGOResponse
    {
        AsyncCallback ProcessIncomingRumor;
        ReceiveCallback receiveCallback;
        int incoming = 0;
        static List<string> uniqueReceivedRumors = new List<string>();

        public GOUserReceive(
            QS.Fx.Object.IContext _mycontext,
            [QS.Fx.Reflection.Parameter("GOTransport", QS.Fx.Reflection.ParameterClass.Value)] 
                QS.Fx.Object.IReference<IGOTransport> goTransport)
        {
            InitializeComponent();
            this.uiendpoint = _mycontext.ExportedUI(this);
            this.goEndpoint = _mycontext.DualInterface<IGORequest, IGOResponse>(this);
            this.goConnection = this.goEndpoint.Connect(goTransport.Dereference(_mycontext).goTransport);
        }

        private void processIncomingRumor(IAsyncResult _result)
        {
            const int MAX_RUMORS_TO_RECEIVE = 10;

            ReceiveCallback d = (ReceiveCallback)((AsyncResult)_result).AsyncDelegate;

            Rumor r = d.EndInvoke(_result);
            if (r != null)
            {
                if (incoming == 0)
                {
                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = progressBar1.Minimum + MAX_RUMORS_TO_RECEIVE;
                }
                if (!uniqueReceivedRumors.Contains(r.Id))
                {
                    uniqueReceivedRumors.Add(r.Id);


                    listView1.Items.Add(new ListViewItem("[" + incoming + "] " + " "
                                     + "rumor id: " + r.Id
                                     + ", hop count: " + r.HopCount
                                     + ", source group: " + r.SourceGroup.Id
                                     + ", destination group: " + r.DestinationGroup.Id
                                     + ", source node: " + r.SourceNode.Id
                                     + ", destination node: " + r.DestinationNode.Id
                                     + ", payload: " + r.PayLoad
                                     + ", size: " + r.Size));
                    incoming++;
                    progressBar1.Value = incoming;
                }

                if (incoming == MAX_RUMORS_TO_RECEIVE)
                {
                    button1.Text = "Done";
                    button1.Enabled = false;

                    label2.BackColor = System.Drawing.Color.LightBlue;
                    
                    return;
                }

                d.BeginInvoke(ProcessIncomingRumor, null);
            }
        }
 
        private QS.Fx.Endpoint.Internal.IExportedUI uiendpoint;
        private QS.Fx.Endpoint.Internal.IDualInterface<IGORequest, IGOResponse> goEndpoint;
        private QS.Fx.Endpoint.IConnection goConnection;
        
        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return this.uiendpoint; }
        }

        void IGOResponse.Ready()
        {
            //this.RefreshCallback();
        }

        void IGOResponse.Alert(Rumor rumor)
        {
            // [TODO]
        }

        #region IGOResponse Members

        void IGOResponse.Notify(QS.Fx.Object.IReference<QS.Fx.Object.Classes.IObject> notifyMessage)
        {
            throw new NotImplementedException();
        }

        #endregion


        private void button1_Click_1(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(listView1, "Incoming gossips at Node_2, \r\nclick to see details");

            goEndpoint.Interface.SetWorkingContext("30002");
            ProcessIncomingRumor = new AsyncCallback(processIncomingRumor);
            receiveCallback = new ReceiveCallback(goEndpoint.Interface.BeginToFetch);
            IAsyncResult ar1 = receiveCallback.BeginInvoke(ProcessIncomingRumor, null);
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
            
        }

    }
}
