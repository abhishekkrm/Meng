﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SomeStuff
{
    [QS.Fx.Reflection.ValueClass("2`1", "Accounts")]
    public sealed class Accounts
    {
        public Accounts(Account[] accounts)
        {
            this.accounts = accounts;
        }

        public Accounts()
        {
        }

        [XmlElement]
        public Account[] accounts;
    }
}
