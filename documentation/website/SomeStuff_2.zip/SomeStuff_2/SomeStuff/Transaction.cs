﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SomeStuff
{
    [QS.Fx.Reflection.ValueClass("3`1", "Transaction")]
    public sealed class Transaction
    {
        public Transaction(string from, string to, double amount)
        {
            this.from = from;
            this.to = to;
            this.amount = amount;
        }

        public Transaction()
        {
        }

        [XmlAttribute]
        public string from, to;
        [XmlAttribute]
        public double amount;
    }
}
