﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SomeStuff
{
    [QS.Fx.Reflection.ObjectClass("1`1", "Bank")]
    public interface IBank : QS.Fx.Object.Classes.IObject
    {
        [QS.Fx.Reflection.Endpoint("Bank")]
        QS.Fx.Endpoint.Classes.IDualInterface<IOutgoing, IIncoming> Bank
        {
            get;
        }
    }
}
