﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SomeStuff
{
    [QS.Fx.Reflection.InterfaceClass("2`1", "Outgoing")]
    public interface IOutgoing : QS.Fx.Interface.Classes.IInterface
    {
        [QS.Fx.Reflection.Operation("Ready")]
        void Ready();

        [QS.Fx.Reflection.Operation("Alert")]
        void Alert(string user, double amount);
    }
}
