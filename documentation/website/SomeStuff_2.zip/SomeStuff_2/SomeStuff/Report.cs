﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SomeStuff
{
    [QS.Fx.Reflection.ComponentClass("3`1", "Report")]
    public sealed partial class Report : 
        UserControl, 
        QS.Fx.Object.Classes.IUI,
        IOutgoing
    {
        public Report(
            [QS.Fx.Reflection.Parameter("bank", QS.Fx.Reflection.ParameterClass.Value)] 
                QS.Fx.Object.IReference<IBank> bank)
        {
            InitializeComponent();
            this.uiendpoint = QS.Fx.Endpoint.Internal.Create.ExportedUI(this);
            this.bankendpoint = QS.Fx.Endpoint.Internal.Create.DualInterface<IIncoming, IOutgoing>(this);
            this.bankconnection = this.bankendpoint.Connect(bank.Object.Bank);
            if (this.bankendpoint.Interface.Ready())
                this.RefreshCallback();
        }

        private QS.Fx.Endpoint.Internal.IExportedUI uiendpoint;
        private QS.Fx.Endpoint.Internal.IDualInterface<IIncoming, IOutgoing> bankendpoint;
        private QS.Fx.Endpoint.IConnection bankconnection;

        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return this.uiendpoint; }
        }

        void IOutgoing.Ready()
        {
            this.RefreshCallback();
        }

        void IOutgoing.Alert(string user, double amount)
        {
            this.RefreshCallback();
        }

        private void RefreshCallback()
        {
            if (listView1.InvokeRequired)
                listView1.BeginInvoke(new QS.Fx.Base.Callback(this.RefreshCallback));
            else
            {
                Accounts accounts = this.bankendpoint.Interface.Accounts();
                lock (this)
                {
                    listView1.BeginUpdate();
                    listView1.Items.Clear();
                    if (accounts.accounts != null)
                        foreach (Account account in accounts.accounts)
                            listView1.Items.Add(new ListViewItem(new string[] { account.user, account.balance.ToString() }));
                    listView1.EndUpdate();
                    listView1.Refresh();
                }
            }
        }
    }
}
