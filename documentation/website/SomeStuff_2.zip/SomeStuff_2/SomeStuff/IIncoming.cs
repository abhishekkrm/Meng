﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SomeStuff
{
    [QS.Fx.Reflection.InterfaceClass("1`1", "Incoming")]
    public interface IIncoming : QS.Fx.Interface.Classes.IInterface
    {
        [QS.Fx.Reflection.Operation("Ready")]
        bool Ready();

        [QS.Fx.Reflection.Operation("Accounts")]
        Accounts Accounts();

        [QS.Fx.Reflection.Operation("Transfer")]
        void Transfer(string from, string to, double amount);

        [QS.Fx.Reflection.Operation("Deposit")]
        void Deposit(string to, double amount);

        [QS.Fx.Reflection.Operation("Withdraw")]
        void Withdraw(string from, double amount);
    }
}
