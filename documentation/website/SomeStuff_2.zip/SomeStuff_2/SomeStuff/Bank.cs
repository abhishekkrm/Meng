﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SomeStuff
{
    [QS.Fx.Reflection.ComponentClass("2`1", "Bank")]
    public sealed class Bank : 
        IBank,
        IIncoming,
        QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>
    {
        public Bank(
            [QS.Fx.Reflection.Parameter("channel", QS.Fx.Reflection.ParameterClass.Value)]
            QS.Fx.Object.IReference<
                QS.Fx.Object.Classes.ICheckpointedCommunicationChannel<Transaction, Accounts>> channel)
        {
            this.bankendpoint = QS.Fx.Endpoint.Internal.Create.DualInterface<IOutgoing, IIncoming>(this);
            this.channelendpoint = QS.Fx.Endpoint.Internal.Create.DualInterface<
                QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<Transaction, Accounts>,
                QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>>(this);
            this.channelconnection = this.channelendpoint.Connect(channel.Object.Channel);
        }

        private IDictionary<string, Account> myaccounts = new Dictionary<string, Account>();
        private bool ready;
        private QS.Fx.Endpoint.Internal.IDualInterface<IOutgoing, IIncoming> bankendpoint;
        private QS.Fx.Endpoint.Internal.IDualInterface<
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannel<Transaction, Accounts>,
            QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>> channelendpoint;
        private QS.Fx.Endpoint.IConnection channelconnection;

        QS.Fx.Endpoint.Classes.IDualInterface<IOutgoing, IIncoming> IBank.Bank
        {
            get { return this.bankendpoint; }
        }

        Accounts QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>.Checkpoint()
        {
            lock (this)
            {
                return new Accounts((new List<Account>(this.myaccounts.Values)).ToArray());
            }
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>.Initialize(Accounts _checkpoint)
        {
            lock (this)
            {
                this.myaccounts.Clear();
                if ((_checkpoint != null) && (_checkpoint.accounts != null))
                    foreach (Account account in _checkpoint.accounts)
                        this.myaccounts.Add(account.user, account);
                this.ready = true;
                if (this.bankendpoint.IsConnected)
                    this.bankendpoint.Interface.Ready();
            }
        }

        void QS.Fx.Interface.Classes.ICheckpointedCommunicationChannelClient<Transaction, Accounts>.Receive(Transaction _message)
        {
            List<Account> alerts = new List<Account>();
            lock (this)
            {
                Account account;
                bool ok = true;
                if ((_message.from != null) && (_message.from.Length > 0))
                {
                    if (this.myaccounts.TryGetValue(_message.from, out account))
                    {
                        account.balance -= _message.amount;
                        alerts.Add(account);
                    }
                    else
                        ok = false;
                }
                if (ok && (_message.to != null) && (_message.to.Length > 0))
                {
                    if (this.myaccounts.TryGetValue(_message.to, out account))
                        account.balance += _message.amount;
                    else
                    {
                        account = new Account(_message.to, _message.amount);
                        this.myaccounts.Add(_message.to, account);
                    }
                    alerts.Add(account);
                }
            }
            foreach (Account account in alerts)
                this.bankendpoint.Interface.Alert(account.user, account.balance);
        }

        bool IIncoming.Ready()
        {
            return this.ready;
        }

        Accounts IIncoming.Accounts()
        {
            lock (this)
            {
                return new Accounts((new List<Account>(this.myaccounts.Values)).ToArray());
            }
        }

        void IIncoming.Transfer(string from, string to, double amount)
        {
            this.channelendpoint.Interface.Send(new Transaction(from, to, amount));
        }

        void IIncoming.Deposit(string to, double amount)
        {
            this.channelendpoint.Interface.Send(new Transaction(null, to, amount));
        }

        void IIncoming.Withdraw(string from, double amount)
        {
            this.channelendpoint.Interface.Send(new Transaction(from, null, amount));
        }
    }
}
