﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace SomeStuff
{
    [QS.Fx.Reflection.ValueClass("1`1", "Account")]
    public sealed class Account
    {
        public Account(string user, double balance)
        {
            this.user = user;
            this.balance = balance;
        }

        public Account()
        {
        }
        
        [XmlAttribute]
        public string user;
        [XmlAttribute]
        public double balance;
    }
}
