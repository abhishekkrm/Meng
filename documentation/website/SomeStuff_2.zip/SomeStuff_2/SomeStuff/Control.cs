﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SomeStuff
{
    [QS.Fx.Reflection.ComponentClass("4`1", "Control")]
    public sealed partial class Control : 
        UserControl,
        QS.Fx.Object.Classes.IUI,
        IOutgoing
    {
        public Control(
            [QS.Fx.Reflection.Parameter("bank", QS.Fx.Reflection.ParameterClass.Value)] 
                QS.Fx.Object.IReference<IBank> bank)
        {
            InitializeComponent();
            this.uiendpoint = QS.Fx.Endpoint.Internal.Create.ExportedUI(this);
            this.bankendpoint = QS.Fx.Endpoint.Internal.Create.DualInterface<IIncoming, IOutgoing>(this);
            this.bankconnection = this.bankendpoint.Connect(bank.Object.Bank);
        }

        private QS.Fx.Endpoint.Internal.IExportedUI uiendpoint;
        private QS.Fx.Endpoint.Internal.IDualInterface<IIncoming, IOutgoing> bankendpoint;
        private QS.Fx.Endpoint.IConnection bankconnection;

        QS.Fx.Endpoint.Classes.IExportedUI QS.Fx.Object.Classes.IUI.UI
        {
            get { return this.uiendpoint; }
        }

        void IOutgoing.Ready()
        {
        }

        void IOutgoing.Alert(string user, double amount)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string from = textBox1.Text;
                if (from.Length == 0)
                    from = null;
                string to = textBox2.Text;
                if (to.Length == 0)
                    to = null;
                double amount = Convert.ToDouble(textBox3.Text);
                this.bankendpoint.Interface.Transfer(from, to, amount);
            }
            catch (Exception)
            {
            }
        }
    }
}
